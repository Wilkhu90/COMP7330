/*    Author: 	Sumeet Wilkhu
   Auburn ID: 	903769076
   File Name:	parraysum.c
  Compile by:	mpicc parraysum.c -o parraysum
       Usage:   2 ways to use:-
		  a) Type mpirun -np <number of processors> parraysum <data file>(In case you just want to check whether the program is running or not.)
		  b) Type run_script myscript.sh and give the inputs asked before inserting the program into dmc queue. (Preffered as it runs 50 times with the desired number of processors.)

 */

#include "mpi.h"
#include <stdio.h>
#include <math.h>
#include <time.h>

void readArray(char * fileName, double ** a, int * n);
double sumArray(double * a, int low, int high) ;

int main(int argc, char * argv[])
{
  int  howMany;
  double myresult=0.0, result=0.0;
  double * a;
  int myid, numprocs, x, low, high;
  double start, end;
  double  diff;

  if (argc != 2) {
    fprintf(stderr, "\n*** Usage: mpiexec ./parraySum <inputFile>\n\n");
    exit(1);
  }
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Comm_rank(MPI_COMM_WORLD, &myid);
  if(myid == 0){
    start = MPI_Wtime();
  }
  readArray(argv[1], &a, &howMany);
  /* broadcast data */
  MPI_Bcast(a,howMany, MPI_DOUBLE, 0, MPI_COMM_WORLD);

  /* add portion of data */
  if (howMany%numprocs == 0){
    x = howMany/numprocs;
    low = myid * x;
    high = low + x;
  }
  else{
    if(myid == 0) {
      x = (howMany/numprocs);
      low = x*(numprocs-1);
      high = howMany;
    }
    else{
      x = howMany/numprocs;
      low = (myid-1) * x;
      high = low + x;
    }
  }
  /*compute local sum */
  myresult = sumArray(a, low, high);

  /* compute global sum */
  MPI_Reduce(&myresult, &result, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

  if(myid == 0) {
    end = MPI_Wtime();
    diff = (end - start);
    printf("Total sum= %lf M= %d N= %d Time Taken= %lf\n", result, howMany, numprocs, diff);
  }

  MPI_Finalize();
  
  return 0;
}

void readArray(char * fileName, double ** a, int * n) {
  int count, howMany;
  double * tempA;
  FILE * fin;

  fin = fopen(fileName, "r");
  if (fin == NULL) {
    fprintf(stderr, "\n*** Unable to open input file '%s'\n\n",
      fileName);
    exit(1);
  }

  fscanf(fin, "%d", &howMany);
  tempA = malloc(howMany * sizeof(double));
  if (tempA == NULL) {
    fprintf(stderr, "\n*** Unable to allocate %d-length array",
      howMany);
    exit(1);
  }

  for (count = 0; count < howMany; count++) {
    fscanf(fin, "%lf", &tempA[count]);
  }

  fclose(fin);

  *n = howMany;
  *a = tempA;
}

double sumArray(double * a, int low, int high) {

  int i;
  double myresult=0.0;

  for(i=low; i<high; i++) {
    myresult += a[i];
  }
  
  return myresult;
}
