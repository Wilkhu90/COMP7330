In order to execute on DMC there are steps to be followed:

a) Please compile the program parraysum.c by typing "mpicc parraysum.c -o parraysum".

b) Once program is compiled, you can easily run the program by either typing, "mpirun -np <number of processors> parraysum <input File>". By running it like this, you are only running it on local system only. Hence, you are restricted by the number of processors your system has.

c) Or you can use the more preffered way, by typing "run_script myscript.sh" and insert the information being asked in the command line of dmc. Once done, you can verify your results in the output file generated. In my script, I am also extrapolating all the results into a csv file called, "final.csv". The final.csv hold all the outputs from all the 500 runs.

