#!/bin/sh
# script to run the program on dmc
source /opt/asn/etc/asn-bash-profiles-special/modules.sh
module load openmpi
files=(data100.txt data1000.txt data10000.txt data100000.txt data1000000.txt)

for file in "${files[@]}"
do
    for i in {1..10}
    do
        echo "$(mpiexec ./parraysum $file)" >> B
	awk '{print $3, $5, $7, $10}' < B > output.csv
	printf "The result of run $i from $file\n"
	printf "Sum         M  N  RunTime\n"
	tail -1 output.csv
    done
    printf "\n"
done
cat output.csv >> final.csv
rm -f B output.csv
